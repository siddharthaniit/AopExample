package com.example.aop;

import org.springframework.stereotype.Component;

@Component
public class A {
	
	public void show()
	{
		System.out.println("Hello world");
	}

}
