package com.example.aop;

public class Savinay {
	public static void main(String[] args) {
		
		String a = "savinay";
		String b = "savinay";
		if(a == b)
		{
			System.out.println(true);
		}
		else
		{
			System.out.println(false);
		}
		
	}

}
